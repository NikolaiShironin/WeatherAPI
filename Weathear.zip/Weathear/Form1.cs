﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Weathear
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string url = "https://api.openweathermap.org/data/2.5/weather?lat=55.707086&lon=38.958712&appid=0fb33c4a59bcf9edff5f7101358e0fec";
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse res = (HttpWebResponse)req.GetResponse();
            StreamReader reader = new StreamReader(res.GetResponseStream());
            string response = reader.ReadToEnd();
            richTextBox1.Text= response;
            WeatherResponse wr = JsonConvert.DeserializeObject<WeatherResponse>(response);
            ICity.Text = wr.Name;
            ITemperatura.Text = wr.Main.Temp.ToString();
        }
    }
}
